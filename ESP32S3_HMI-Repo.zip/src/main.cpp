#include <Arduino.h>

#include "lvgl_port.h"       // LVGL porting functions for integration


void setup() {
    Serial0.begin(115200);
    delay(200);
    Serial0.println();
    Serial0.println("HMI Display Boot");   
    
    auto tp_handle = touch_gt911_init();
    auto panel_handle = waveshare_esp32_s3_rgb_lcd_init();
    wavesahre_rgb_lcd_bl_on();

    ESP_ERROR_CHECK(lvgl_port_init(panel_handle, tp_handle));

    if (lvgl_port_lock(-1))
    {
        lv_obj_set_style_bg_color(lv_scr_act(), lv_color_black(), 0);
        lv_obj_set_style_bg_opa(lv_scr_act(), LV_OPA_COVER, 0);

        lv_obj_t* label = lv_label_create(lv_scr_act());
        lv_label_set_text(label, "BOOT OK");
        lv_obj_set_style_text_color(label, lv_color_white(), 0);
        lv_obj_center(label);

        lvgl_port_unlock();
    }

    Serial0.println("Display ready");
}

void loop() {
  delay(10);
}